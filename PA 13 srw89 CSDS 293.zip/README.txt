Open the src folder, and then open the java files to access the code.
Open the report file for junit and jacoco tests.
Open the doc folder for HTML files for documentation.